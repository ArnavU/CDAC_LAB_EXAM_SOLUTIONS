package com.sunbeam;

public class Customer {
	// customerId, customerName, // contactNumber
	private int customerId;
	private String customerName;
	private String contactNumber;
	public Customer() {}
	public Customer(int customerId, String customerName, String contactNumber) {
		this.customerId = customerId;
		this.customerName = customerName;
		this.contactNumber = contactNumber;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerName=" + customerName + ", contactNumber="
				+ contactNumber + "]";
	}
	@Override
	public boolean equals(Object obj) {
		if(obj == null)
			return false;
		if(obj == this)
			return true;
		if(!(obj instanceof Customer))
			return false;
		Customer other = (Customer)obj;
		return this.customerId == other.customerId;
	}
}





