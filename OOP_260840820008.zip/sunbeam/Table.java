package com.sunbeam;

import java.util.ArrayList;
import java.util.List;

public class Table implements Comparable<Table> {
	// tableNumber, capacity, price, customer
	private int tableNumber;
	private int capacity;
	private double price;
	private List<Customer> customerList;
	public Table() {
		this.customerList = new ArrayList<>();
	}
	public Table(int tableNumber, int capacity, double price) {
		this.tableNumber = tableNumber;
		this.capacity = capacity;
		this.price = price;
		this.customerList = new ArrayList<>();
	}
	public int getReserveCount() {
		return customerList.size();
	}
	public void addCustomer(Customer c) {
		customerList.add(c);
	}
	public int getTableNumber() {
		return tableNumber;
	}
	public void setTableNumber(int tableNumber) {
		this.tableNumber = tableNumber;
	}
	public int getCapacity() {
		return capacity;
	}
	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public List<Customer> getCustomerList() {
		return customerList;
	}
	public void setCustomerList(List<Customer> customerList) {
		this.customerList = customerList;
	}
	@Override
	public String toString() {
		return "Restaurant [tableNumber=" + tableNumber + ", capacity=" + capacity + ", price=" + price
				+ ", \n    customerList=" + customerList + "]";
	}	
	@Override
	public boolean equals(Object obj) {
		if(obj == null)
			return false;
		if(obj == this)
			return true;
		if(!(obj instanceof Table))
			return false;
		Table other = (Table) obj;
		return this.getTableNumber() == other.getTableNumber();
	}
	@Override
	public int compareTo(Table obj) {
		return Integer.compare(this.getTableNumber(), obj.getTableNumber());
	}
}
