package com.sunbeam;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class DuplicateTableException extends Exception {
	public DuplicateTableException(String message) {
		super(message);
	}
}
class DuplicateCustomerException extends Exception {
	public DuplicateCustomerException(String message) {
		super(message);
	}
}
class InvalidInputException extends Exception {
	public InvalidInputException(String message) {
		super(message);
	}
}
class CustomerNotFoundException extends Exception {
	public CustomerNotFoundException(String message) {
		super(message);
	}
}
class TableNotFoundException extends Exception {
	public TableNotFoundException(String message) {
		super(message);
	}
}
class CustomerAlreadyReservedExcetion extends Exception {
	public CustomerAlreadyReservedExcetion(String message) {
		super(message);
	}
}
class CapacityFullException extends Exception {
	public CapacityFullException(String message) {
		super(message);
	}
}
class InvalidChoiceException extends Exception {
	public InvalidChoiceException(String message) {
		super(message);
	}
}
class AssignmentToSameTableException extends Exception {
	public AssignmentToSameTableException(String message) {
		super(message);
	}
}

public class Program {
	static List<Customer> custList = new ArrayList<>();
	static List<Table> tableList = new ArrayList<>();
	static Scanner sc = new Scanner(System.in);
	
	static public Table acceptTable() throws DuplicateTableException, InvalidInputException {
		int tableNo;
		int capacity;
		double price;
		
		System.out.print("Enter table no.: ");
		tableNo = sc.nextInt();
		
		Table key = new Table();
		key.setTableNumber(tableNo);
		if(tableList.indexOf(key) != -1) {
			throw new DuplicateTableException("Duplicate table entries!!");
		}
		
		System.out.print("Enter capacity: ");
		capacity = sc.nextInt();
		
		if(capacity <= 0) 
			throw new InvalidInputException("Capacity must be positive!!!");
		
		System.out.print("Enter price: ");
		price = sc.nextDouble();
		
		if(price < 0)
			throw new InvalidInputException("Price must be positive!!!");
		
		Table t = new Table(tableNo, capacity, price);
		
		return t;
	}
	public static Customer acceptCustomer() throws DuplicateCustomerException {
		int custId;
		String custName;
		String contactNumber;
		
		System.out.print("Enter the customer id: ");
		custId = sc.nextInt();
		
		Customer key = new Customer();
		key.setCustomerId(custId);
		if(custList.indexOf(key) != -1) 
			throw new DuplicateCustomerException("Customer already exists!!!");
		
		System.out.print("Enter customer name: ");
		custName = sc.next();
		
		System.out.print("Enter customer contact number: ");
		contactNumber = sc.next();
		
		Customer c = new Customer(custId, custName, contactNumber);
		
		return c;
	}
	
	public static void acceptCustomerNo(int[] custId) {
		System.out.println("Enter customer id: ");
		custId[0] = sc.nextInt();
	}
	public static void acceptTableNo(int[] tableNo) {
		System.out.println("Enter table no: ");
		tableNo[0] = sc.nextInt();
	}
	public static boolean checkIfCustExists(int custId) {
		Customer key = new Customer();
		key.setCustomerId(custId);
		if(custList.indexOf(key) == -1) return false;
		return true;
	}
	public static boolean checkIfTableExists(int tableNo) {
		Table key = new Table();
		key.setTableNumber(tableNo);
		if(tableList.indexOf(key) == -1) return false;
		return true;
	}
	public static boolean checkIfCustomerReserved(int custId) {
		for(Table table : tableList) {
			for(Customer c : table.getCustomerList()) {
				if(c.getCustomerId()==custId) {
					return true;
				}
			}
		}
		return false;
	}
	public static boolean checkIfCapacityFull(int tableNo) {
		Table key = new Table();
		key.setTableNumber(tableNo);
		int idx = tableList.indexOf(key);
		if(tableList.get(idx).getCustomerList().size() == tableList.get(idx).getCapacity())
			return true;
		return false;
	}
	public static void reserveTable(int custId, int tableNo) {
		Customer cKey = new Customer();
		cKey.setCustomerId(custId);
		
		Table tKey = new Table();
		tKey.setTableNumber(tableNo);

		int cIdx = custList.indexOf(cKey);
		int tIdx = tableList.indexOf(tKey);
		
		Customer c = custList.get(cIdx);
		Table t = tableList.get(tIdx);
		t.addCustomer(c);
		
	}
	public static void cancelReservation(int custId) {
		for(Table t : tableList) {
			Customer key = new Customer();
			key.setCustomerId(custId);
			int idx = t.getCustomerList().indexOf(key);
			if(idx!=-1) {
				t.getCustomerList().remove(key);
				System.out.println("Success!!!");
				return;
			}
		}
		System.out.println("Fail!!!");
	}
	public static void printAllTables() {
		for(Table t : tableList) {
			System.out.println(t);
		}
	}
	public static void showTableStatuses() {
		for(Table t : tableList) {
			int tableId = t.getTableNumber();
			int capacity = t.getCapacity();
			int reservedCnt = t.getReserveCount();
			int availableCnt = capacity - reservedCnt;
			System.out.println(String.format("{ Table no: %d, Reserved count: %d, Available count: %d }", tableId, reservedCnt, availableCnt));
		}
	}
	
	static int menuList() {
		System.out.println("0. Exit");
		System.out.println("1. Add Table");
		System.out.println("2. Add Customer");
		System.out.println("3. Reserve Table");
		System.out.println("4. Cancel Reservation.");
		System.out.println("5. Change Customer Table");
		System.out.println("6. Print All Tables");
		System.out.println("7. Show Available and Reserved Tables");
		System.out.println("8. Sort Tables.");
		System.out.print("Enter your choice: ");
		return sc.nextInt();
	}
	
	public static void moveToTable(int custId, int tableNo) throws AssignmentToSameTableException {
		Customer cKey = new Customer();
		cKey.setCustomerId(custId);
		int cIdx = custList.indexOf(cKey);
		
		Customer c = custList.get(cIdx);
		for(Table t: tableList) {
			if(t.getCustomerList().indexOf(c)!=-1) {
				if(tableNo == t.getTableNumber())
					throw new AssignmentToSameTableException("Customer cannot be reserved to the same table!!!");
			}
		}
		
		cancelReservation(custId);
		reserveTable(custId, tableNo);
	}
	
	public static void main(String[] args) {
		int[] custId = {0};
		int[] tableNo = {0};
		int choice;
		boolean isCustExist;
		boolean isTableExist;
		boolean isCustomerReserved;
		boolean isCapacityFull;
		
		while((choice = menuList()) != 0) {
			try {
				switch(choice) {
				case 1: // add table
					Table t = acceptTable();
					tableList.add(t);
					break;
				case 2: // add customer
					Customer c = acceptCustomer();
					custList.add(c);
					break;
				case 3: // reserve table
					acceptCustomerNo(custId);
					acceptTableNo(tableNo);
					isCustExist = checkIfCustExists(custId[0]);
					if(isCustExist == false) 
						throw new CustomerNotFoundException("No such customer found!!");
					isTableExist = checkIfTableExists(tableNo[0]);
					if(isTableExist == false)
						throw new TableNotFoundException("No such table exists!!");
					isCustomerReserved = checkIfCustomerReserved(custId[0]);
					if(isCustomerReserved == true)
						throw new CustomerAlreadyReservedExcetion("Customer already reserved!!");
					isCapacityFull = checkIfCapacityFull(tableNo[0]);
					if(isCapacityFull == true)
						throw new CapacityFullException("Capacity of table full!!!");
					reserveTable(custId[0], tableNo[0]);
					System.out.println("Reservation successfull!!!");
					break;
				case 4: // cancel reservation
					acceptCustomerNo(custId);
					isCustExist = checkIfCustExists(custId[0]);
					if(isCustExist == false) 
						throw new CustomerNotFoundException("No such customer found!!");
					isCustomerReserved = checkIfCustomerReserved(custId[0]);
					if(isCustomerReserved == false)
						throw new CustomerAlreadyReservedExcetion("Customer must be reserved before removing!!");
					cancelReservation(custId[0]);
					System.out.println("Reservation cancelled!!");
					break;
				case 5: // change cust tables *****************************************************
					acceptCustomerNo(custId);
					acceptTableNo(tableNo);
					isCustExist = checkIfCustExists(custId[0]);
					if(isCustExist == false) 
						throw new CustomerNotFoundException("No such customer found!!");
					isCustomerReserved = checkIfCustomerReserved(custId[0]);
					if(isCustomerReserved == false)
						throw new CustomerAlreadyReservedExcetion("Customer must be reserved before moving!!");
					isTableExist = checkIfTableExists(tableNo[0]);
					if(isTableExist == false)
						throw new TableNotFoundException("No such table exists!!");
					moveToTable(custId[0], tableNo[0]);
					break;
				case 6: // print all tables
					printAllTables();
					break;
				case 7: // show available and reserved tales
					showTableStatuses();
					break;
				case 8: // sort tables by id
					tableList.sort(null);
					printAllTables();
					break;		
				default: 
					throw new InvalidChoiceException("Enter the choice with 0-8.");
				}
			} 
			catch(Exception e) {
				System.out.println(e.getMessage());
//				e.printStackTrace();
			}
			
		}
	}
}
















